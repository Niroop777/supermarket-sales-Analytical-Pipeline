# Databricks notebook source
# Set storage account key for ADLS access
spark.conf.set(
    "fs.azure.account.key.niroop.dfs.core.windows.net",
    "LaqTptKHYXSUbg6Pol2V/yaeHVu0645P+PbdpQtZdlv017o1Eru+J9isKgdFfarFr4bypgmYduyr+AStuHxTSA=="
)

# COMMAND ----------

# Create Bronze database
spark.sql("""
CREATE DATABASE IF NOT EXISTS supermarket_bronze_db
LOCATION 'abfss://bronze@niroop.dfs.core.windows.net/supermarket/bronze'
""")

# Create Silver database
spark.sql("""
CREATE DATABASE IF NOT EXISTS supermarket_silver_db
LOCATION 'abfss://silver@niroop.dfs.core.windows.net/supermarket/silver'
""")

# Create Gold database
spark.sql("""
CREATE DATABASE IF NOT EXISTS supermarket_gold_db
LOCATION 'abfss://gold@niroop.dfs.core.windows.net/supermarket/gold'
""")