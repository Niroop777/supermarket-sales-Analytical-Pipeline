# Databricks notebook source
from pyspark.sql.types import *

# File path
data_path = "abfss://raw@niroop.dfs.core.windows.net/supermarket/supermarket_sales_large_messy.csv"

# Define schema
schema = StructType([
    StructField("InvoiceID", StringType(), True),
    StructField("Date", DateType(), True),
    StructField("Branch", StringType(), True),
    StructField("CustomerType", StringType(), True),
    StructField("Gender", StringType(), True),
    StructField("ProductLine", StringType(), True),
    StructField("UnitPrice", DoubleType(), True),
    StructField("Quantity", IntegerType(), True),
    StructField("Tax", DoubleType(), True),
    StructField("Total", DoubleType(), True),
    StructField("Payment", StringType(), True),
    StructField("COGS", DoubleType(), True),
    StructField("GrossMargin", DoubleType(), True),
    StructField("GrossIncome", DoubleType(), True),
    StructField("Rating", DoubleType(), True)
])

# COMMAND ----------

# Read data
df_bronze = spark.read.format("csv") \
    .option("header", True) \
    .schema(schema) \
    .load(data_path)

# COMMAND ----------

display(df_bronze)

# COMMAND ----------

df_bronze.count()

# COMMAND ----------

# Write to Bronze Delta table in ADLS
bronze_path = "abfss://bronze@niroop.dfs.core.windows.net/supermarket/bronze/supermarket_sales_bronze"

df_bronze.write.format("delta") \
    .mode("overwrite") \
    .save(bronze_path)

# Register table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS supermarket_bronze_db.supermarket_sales_bronze
USING DELTA
LOCATION '{bronze_path}'
""")