# Databricks notebook source
from pyspark.sql.functions import col, month

# Read from Bronze table
df_bronze = spark.read.table("supermarket_bronze_db.supermarket_sales_bronze")

# COMMAND ----------

# Data Quality Checks
# Nulls
critical_columns = ["InvoiceID", "Date", "ProductLine", "Total"]
for c in critical_columns:
    null_count = df_bronze.filter(col(c).isNull()).count()
    print(f"Null count in {c}: {null_count}")

# from pyspark.sql.functions import col, trim

# # Enhanced null/empty checks
# critical_columns = ["InvoiceID", "Date", "ProductLine", "Total"]
# for c in critical_columns:
#     null_or_empty = df_bronze.filter((col(c).isNull()) | (trim(col(c)) == "")).count()
#     print(f"Null or empty count in {c}: {null_or_empty}")

# COMMAND ----------

# Negative totals
neg_total = df_bronze.filter(col("Total") < 0).count()
print(f"Negative totals count: {neg_total}")

# COMMAND ----------

# Duplicates on InvoiceID
dup_count = df_bronze.groupBy("InvoiceID").count().filter(col("count") > 1).count()
print(f"Duplicate InvoiceIDs count: {dup_count}")

# COMMAND ----------

# Clean data
df_cleaned = df_bronze.dropna(subset=critical_columns)
df_cleaned = df_cleaned.filter(col("Total") >= 0)

# COMMAND ----------

# Standardize column names and derive month
for c in df_cleaned.columns:
    df_cleaned = df_cleaned.withColumnRenamed(c, c.lower().replace(" ", "_"))

df_cleaned = df_cleaned.withColumn("month", month(col("date")))

# COMMAND ----------

display(df_cleaned)

# COMMAND ----------

# Write to Silver with partitioning
silver_path = "abfss://silver@niroop.dfs.core.windows.net/supermarket/silver/supermarket_sales_silver"

df_cleaned.write.format("delta") \
    .mode("overwrite") \
    .partitionBy("branch") \
    .save(silver_path)

# Register table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS supermarket_silver_db.supermarket_sales_silver
USING DELTA
LOCATION '{silver_path}'
""")