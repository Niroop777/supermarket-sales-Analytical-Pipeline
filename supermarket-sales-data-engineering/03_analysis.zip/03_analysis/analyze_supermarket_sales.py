# Databricks notebook source
# MAGIC %md
# MAGIC ##  03_analysis/analyze_supermarket_sales

# COMMAND ----------

# Read from Silver
df_silver = spark.read.table("supermarket_silver_db.supermarket_sales_silver")

# COMMAND ----------

# Product sales summary
df_product_sales = df_silver.groupBy("productline") \
    .agg({"total": "sum"}) \
    .withColumnRenamed("sum(total)", "total_sales") \
    .orderBy("total_sales", ascending=False)

display(df_product_sales)

# COMMAND ----------

# Write to Gold with partitioning by productline
# Set storage account key for ADLS access

df_product_sales = spark.createDataFrame([('product1', 'line1', 100), ('product2', 'line2', 200)], schema=['product', 'productline', 'sales'])

gold_path_product = "abfss://gold@niroop.dfs.core.windows.net/supermarket/gold/product_sales_summary"


df_product_sales.write.format("delta") \
    .mode("overwrite") \
    .partitionBy("productline") \
    .save(gold_path_product)

# Register table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS supermarket_gold_db.product_sales_summary
USING DELTA
LOCATION '{gold_path_product}'
""")

# COMMAND ----------

display(df_monthly_sales)

# COMMAND ----------

display(df_payment)